<?php
include('db_conection.php');
include('dbconection.php');
date_default_timezone_set("Asia/Kolkata");
	$d= date("Y-m-d");
	$t= date ("h:i:sa");
	
	if(isset($_POST['agencyid']))
	{
		$agencyid=$_POST['agencyid'];
		$billno=$_POST['purbillno'];
		$amount=$_POST['amt'];
		$sale=$_POST['rbbill'];
		$puridfetch;
		if($sale=="Cash Sale")
		{
			mysqli_query($con,"Insert into tblpurchase(PurchaseDate,AgencyID,BillNo,Amount,Particulars) values('$d','$agencyid','$billno','$amount','Cash Purchase')");
		$n=mysqli_affected_rows($con);
		$result=mysqli_query($con,"select Max(PurchaseID) as PurchaseID from tblpurchase")->fetch_all(MYSQLI_ASSOC);
		foreach($result as $row)
		{
			$puridfetch=$row['PurchaseID'];
		}
		mysqli_query($con,"Insert into tblsuppliertransaction(SupplierTransactionDate,SupplierTransactionTime,SupplierID,Amount,Particulars) values('$d','$t','$agencyid','$amount','Cash Purchase')");
		$n1=mysqli_affected_rows($con);
		mysqli_query($con,"Insert into tblexpensesincometransaction(ExpensesIncomeDate,ExpensesIncomeTime,Particulars,Amount,PurchaseID,ExpensesAmount) values('$d','$t','Cash Purchase','$amount','$puridfetch','$amount')");
		$n2=mysqli_affected_rows($con);
		if($n>0 && $n1>0 && $n2>0)
		{
			echo "<script>alert('Record Save Successfully!!!');</script>";
		}
		else{
						echo "<script>alert('Record Does Not Successfully!!!');</script>";
		}
		}
		else if($sale=="Credit Sale")
		{
			mysqli_query($con,"Insert into tblpurchase(PurchaseDate,AgencyID,BillNo,Amount,Particulars) values('$d','$agencyid','$billno','$amount','Credit Purchase')");
		$n=mysqli_affected_rows($con);
		mysqli_query($con,"Insert into tblsuppliertransaction(SupplierID,Amount,CrAmount,Particulars) values('$agencyid','$amount','$amount','Credit Purchase')");
		$n2=mysqli_affected_rows($con);
		mysqli_query($con,"update tblsupplier set Balance=Balance+'$amount' where SupplierID='$agencyid'");
		$n1=mysqli_affected_rows($con);
		if($n>0 && $n1>0 && $n2>0)
		{
			echo "<script>alert('Record Save Successfully!!!');</script>";
		}
		else{
						echo "<script>alert('Record Does Not Successfully!!!');</script>";
		}
		}
		else
		{
			echo "<script>alert('Record Does Not Successfully!!!');</script>";
		}
		
		
	}
	?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Medical - Purchase</title>
  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
   <script src='jquery-3.2.1.min.js' type='text/javascript'></script>
   <script src='select2/dist/js/select2.min.js' type='text/javascript'></script>
   <link href='select2/dist/css/select2.min.css' rel='stylesheet' type='text/css'>
   <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</head>

<body id="page-top">
<nav class="navbar" style="background-color:#FBFBFB;box-shadow: 0 4px 2px -2px gray;height:55px;">
  <div class="container-fluid" style="padding:0px;">
     <a href="dashboard.php" class="navbar-brand mb-0 h3" ><i class="fa fa-arrow-left" style="color:#337ab7;font-weight:light;"></i></a>
    <span class=" mb-0 h3" style="text-align:left;margin-right:auto;color:#337ab7;font-size:21px;">Purchase</span>
     
  </div>
</nav>
<div class="container" >
<form  method="POST"  action="Purchase.php" >
<p id="error" style="text-align:center">

</p>

<div class="form-group row">
<div class="col-sm-3 mb-3 sm-mb-0" style="text-align:center;">
<span style="font-size:18px;"><input type="radio" class="form-control-input" name="rbbill" id="rbcash" value="Cash Sale">Cash</span>
<span style="font-size:18px;padding-left:30px;"><input type="radio" class="form-control-input" name="rbbill" id="rbcredit" value="Credit Sale">Credit</span>
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Date :-</label>
<input type="date" class="form-control" name="datepurchase" id="datepurchase" value="<?php echo $d;?>" readonly>
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Agency. :-</label>
<select class="form-control" name="agencyid">
<?php 
$output='<option selected disabled>Select Agency Name</option>';
$query="select SupplierID,AgencyName from tblsupplier";
$result=mysqli_query($con,$query)->fetch_all(MYSQLI_ASSOC);
foreach($result as $row)
{
	$output.='<option value="'.$row['SupplierID'].'">'.$row['AgencyName'].'</option>';
}
echo $output;
?>
</select>
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Bill No :-</label>
<input type="number" class="form-control" name="purbillno" id="purbillno">
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Amount :-</label>
<input type="number" class="form-control" name="amt" id="amt">
</div>
</div>

<div style="text-align:center" style="">
    <input type="submit" class="btn btn-outline-primary form-control" name="Save" id="insert_form" style="width:100px;" value="Save" style="padding-right:30px;">
</div>

</form>
</div>

</body>
</html>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){

$('#insert_form').on('submit', function(event){
        event.preventDefault();
        var error = '';
        var form_data = $(this).serialize();
	
        if(error == '')
        {
          $.ajax({
            url:"Purchase.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
            $('#error').html('<div class="alert alert-success alert-dismissible"> <button type="button" class="close" data-dismiss="alert">&times;</button> <strong>Record Save Successfully</strong> </div>');
            }
          });   
        }
        else
        {
          $('#error').html('<div class="alert alert-danger">'+error+'</div>');
        }
}); 




});
</script>





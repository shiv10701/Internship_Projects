<?php
include('db_conection.php');
include('dbconection.php');
date_default_timezone_set("Asia/Kolkata");
	$d= date("Y-m-d");
	$t= date ("h:i:sa");
$opbal=0;
$todaycash=0;
$cashpurchase=0;
$expenses=0;
$creditsale=0;
$creditpurchase=0;
$cusoutreceived=0;
$suppaidamt=0;
$todayclosingamtval;
$todaytotalincomeval;
$todaytotalexpensesval;
$result=mysqli_query($con,"SELECT sum(Amount) as Amount FROM tblsale where SaleDate='$d' and Particulars='Cash Sale'")->fetch_all(MYSQLI_ASSOC);
foreach($result as $row)
{
	if(!empty($row['Amount']))
	$todaycash=$row['Amount'];
}
$result2=mysqli_query($con,"SELECT sum(Amount) as Amount FROM tblpurchase where PurchaseDate='$d' and Particulars='Cash Purchase'")->fetch_all(MYSQLI_ASSOC);
foreach($result2 as $row)
{
	if(!empty($row['Amount']))
	$cashpurchase=$row['Amount'];
}
$result3=mysqli_query($con,"SELECT TodaysOpeningBalance FROM tbldailyrecording WHERE DailyRecordingDate ='$d'")->fetch_all(MYSQLI_ASSOC);
foreach($result3 as $row)
{
	$opbal=$row['TodaysOpeningBalance'];
}
$result4=mysqli_query($con,"SELECT sum(Amount) as Amount FROM tblsale where SaleDate='$d' and Particulars='Credit Sale'")->fetch_all(MYSQLI_ASSOC);
foreach($result4 as $row)
{
	if(!empty($row['Amount']))
	$creditsale=$row['Amount'];
}
$result5=mysqli_query($con,"SELECT sum(Amount) as Amount FROM tblpurchase where PurchaseDate='$d' and Particulars='Credit Purchase'")->fetch_all(MYSQLI_ASSOC);
foreach($result5 as $row)
{
	if(!empty($row['Amount']))
	$creditpurchase=$row['Amount'];
}
$result6=mysqli_query($con,"SELECT SUM( Amount) as Amount FROM tblcustomertransaction WHERE CustomerTransactionDate = '$d' AND Particulars = 'Pending Amount Received'")->fetch_all(MYSQLI_ASSOC);
foreach($result6 as $row)
{
	if(!empty($row['Amount']))
		$cusoutreceived=$row['Amount'];
}
$result7=mysqli_query($con,"select sum(Amount) as Amount from tblsuppliertransaction where SupplierTransactionDate='$d' and particulars='Pending Amount Paid'")->fetch_all(MYSQLI_ASSOC);
foreach($result7 as $row)
{
	if(!empty($row['Amount']))
	$suppaidamt=$row['Amount'];
}
$result8=mysqli_query($con,"SELECT sum(Amount) as Amount FROM tblexpensesentry WHERE ExpensesDate='$d'")->fetch_all(MYSQLI_ASSOC);
foreach($result8 as $row)
{
	if(!empty($row['Amount']))
		$expenses=$row['Amount'];
}
$todaytotalincomeval=$todaycash+$cusoutreceived;
$todaytotalexpensesval=$cashpurchase+$suppaidamt;
$amountchk=$todaytotalincomeval-$todaytotalexpensesval;
$closingbal=$amountchk+$opbal;

if(isset($_POST['savetoday']))
{
	$cashcounter=$_POST['todaycash'];
	$cashpurchaseamount=$_POST['cashpurchase'];
	$expensesamount=$_POST['expenses'];
	$creditsaleamount=$_POST['creditsale'];
	$creditpurchaseamount=$_POST['creditpurchase'];
	$customeroutreceived=$_POST['coutreceived'];
	$supplieroutpaid=$_POST['suppaidamt'];
	$todayincome=$_POST['todaytotalincome'];
	$todayexpenses=$_POST['todaytotalexpenses'];
	$todayclosing=$_POST['todayclosingamt'];
	$d1= date("Y-m-d", strtotime(' +1 day'));
	$query="update tbldailyrecording set CashCounterAmount ='$cashcounter', CashPurchaseAmount='$cashpurchaseamount',ExpensesAmount='$expensesamount',CreditSaleAmount='$creditsaleamount',CreditPurchaseAmount='$creditpurchaseamount',CustomerOutstandingReceivedAmount='$customeroutreceived',SupplierOutstandingPaidAmount='$supplieroutpaid',TodaysTotalIncome='$todayincome',TodaysTotalExpenses='$todayexpenses',TodaysClosingBalance='$todayclosing' where DailyRecordingDate='$d'";
	mysqli_query($con,$query);
	$n=mysqli_affected_rows($con);
	mysqli_query($con,"Insert into tbldailyrecording(DailyRecordingDate,TodaysOpeningBalance) values('$d1','$todayclosing')");
	$n1=mysqli_affected_rows($con);
	if($n>0 && $n1>0) 
	{
		echo "<script>alert('Record Save Successfully!!!');</script>";
	}
	else{
		echo "<script>alert('Record Does Not Successfully!!!');</script>";
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Medical - Todays</title>
  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
   <script src='jquery-3.2.1.min.js' type='text/javascript'></script>
   <script src='select2/dist/js/select2.min.js' type='text/javascript'></script>
   <link href='select2/dist/css/select2.min.css' rel='stylesheet' type='text/css'>
   <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</head>

<body id="page-top">
<nav class="navbar" style="background-color:#FBFBFB;box-shadow: 0 4px 2px -2px gray;height:55px;">
  <div class="container-fluid" style="padding:0px;">
     <a href="dashboard.php" class="navbar-brand mb-0 h3" ><i class="fa fa-arrow-left" style="color:#337ab7;font-weight:light;"></i></a>
    <span class=" mb-0 h3" style="text-align:left;margin-right:auto;color:#337ab7;font-size:21px;">Today's</span>
     
  </div>
</nav>
<div class="container" >
<form  method="POST"  action="Todays.php" >
<p id="error" style="text-align:center">
</p>

<div class="form-group row">
<div class="col-sm-3 mb-3 sm-mb-0" style="align:left;">
<label class="" style="font-weight:bold;">Opening Balance :-</label>
<input type="number" class="form-control" name="opbal" id="opbal" value="<?php echo $opbal;?>"readonly>
</div>
<div class="col-sm-3 mb-3 sm-mb-0" style="align:left;">
<label class="" style="font-weight:bold;">Today's Cash / Counter :-</label>
<input type="number" class="form-control" name="todaycash" id="todaycash" value="<?php echo $todaycash;?>" readonly>
</div>
<div class="col-sm-3 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Cash Purchase :-</label>
<input type="number" class="form-control" name="cashpurchase" id="cashpurchase" value="<?php echo $cashpurchase;?>" readonly>
</div>
<div class="col-sm-3 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Expenses :-</label>
<input type="text" class="form-control" name="expenses" id="expenses" value="<?php echo $expenses;?>" readonly>
</div>
<div class="col-sm-3 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Credit Sale :-</label>
<input type="number" class="form-control" name="creditsale" id="creditsale" value="<?php echo $creditsale;?>" readonly>
</div>
<div class="col-sm-3 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Credit Purchase :-</label>
<input type="number" class="form-control" name="creditpurchase" id="creditpurchase" value="<?php echo $creditpurchase;?>" readonly>
</div>
<div class="col-sm-3 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">C/O Received :-</label>
<input type="number" class="form-control" name="coutreceived" id="coutreceived" value="<?php echo $cusoutreceived;?>" readonly>
</div>
<div class="col-sm-3 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Supplier Paid :-</label>
<input type="number" class="form-control" name="suppaidamt" id="suppaidamt" value="<?php echo $suppaidamt;?>" readonly>

</div>
<div class="col-sm-3 mb-3 sm-mb-0" hidden>
<input type="number" class="form-control" name="todaytotalincome" id="todaytotalincome" value="<?php echo $todaytotalincomeval;?>" readonly>
<input type="number" class="form-control" name="todaytotalexpenses" id="todaytotalexpenses" value="<?php echo $todaytotalexpensesval;?>" readonly>
<input type="number" class="form-control" name="todayclosingamt" id="todayclosingamt" value="<?php echo $closingbal;?>" readonly>

</div>
</div>

<div style="text-align:center" style="" >
    <input type="submit" class="btn btn-outline-primary form-control" name="savetoday" id="insert_form" style="width:100px;" value="Save" style="padding-right:30px;">
</div>

</form>
</div>

</body>
</html>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
  document.getElementById("mbno").maxLength = "10";

$('#customerid').on('change', function(event){
		  let cusid=$(this).val(); 
		  let flag=2;
	$.ajax({
		url: "fetchValue.php",
		type: "POST",
		data: {cusid: cusid,flag:flag},
		success:function(data)
            {
			var html=data;
                $('#mobileno').val(html); 
            }
		})
});



$('#insert_form').on('submit', function(event){
        event.preventDefault();
        var error = '';
        var form_data = $(this).serialize();
	
        if(error == '')
        {
          $.ajax({
            url:"Todays.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
            $('#error').html('<div class="alert alert-success alert-dismissible"> <button type="button" class="close" data-dismiss="alert">&times;</button> <strong>Record Save Successfully</strong> </div>');
            }
          });   
        }
        else
        {
          $('#error').html('<div class="alert alert-danger">'+error+'</div>');
        }
}); 




});
</script>





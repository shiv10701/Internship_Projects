<?php
include('db_conection.php');
include('dbconection.php');
date_default_timezone_set("Asia/Kolkata");
	$d= date("Y-m-d");
	$t= date ("h:i:sa");
	
	if(isset($_POST['supplierid']))
	{
		$agencyid=$_POST['supplierid'];
		$pendingamt=$_POST['pendingamt'];
		$pamount=$_POST['pamt'];
		$cash=$_POST['cashamt'];
		$online=$_POST['onlineamt'];
		$narration=$_POST['narration'];
		$voucheridfetch;
			mysqli_query($con,"Insert into tblvoucher(Date,SupplierID,PendingAmount,PaidAmount,Cash,Online,Narration) values('$d','$agencyid','$pendingamt','$pamount','$cash','$online','$narration')");
		$n=mysqli_affected_rows($con);
		$result=mysqli_query($con,"select max(VoucherID) as VoucherID from tblvoucher")->fetch_all(MYSQLI_ASSOC);
		foreach($result as $row)
		{
			$voucheridfetch=$row['VoucherID'];
		}
		mysqli_query($con,"Insert into tblsuppliertransaction(SupplierTransactionDate,SupplierTransactionTime,SupplierID,Amount,DrAmount,Particulars,VoucherID) values('$d','$t','$agencyid','$pamount','$pamount','Pending Amount Paid','$voucheridfetch')");
		$n2=mysqli_affected_rows($con);
		mysqli_query($con,"update tblsupplier set Balance=Balance-'$pamount' where SupplierID='$agencyid'");
		$n1=mysqli_affected_rows($con);
		mysqli_query($con,"insert into tblexpensesincometransaction(ExpensesIncomeDate,ExpensesIncomeTime,Particulars,Amount,VoucherID,ExpensesAmount) values('$d','$t','Pening Amount Paid','$pamount','$voucheridfetch','$pamount')");
		$n3=mysqli_affected_rows($con);
		if($n>0 && $n1>0 && $n2>0 && $n3>0)
		{
			echo "<script>alert('Record Save Successfully!!!');</script>";
		}
		else{
						echo "<script>alert('Record Does Not Successfully!!!');</script>";
		}
	}
	?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Medical - Voucher</title>
  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
   <script src='jquery-3.2.1.min.js' type='text/javascript'></script>
   <script src='select2/dist/js/select2.min.js' type='text/javascript'></script>
   <link href='select2/dist/css/select2.min.css' rel='stylesheet' type='text/css'>
   <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</head>

<body id="page-top">
<nav class="navbar" style="background-color:#FBFBFB;box-shadow: 0 4px 2px -2px gray;height:55px;">
  <div class="container-fluid" style="padding:0px;">
     <a href="dashboard.php" class="navbar-brand mb-0 h3" ><i class="fa fa-arrow-left" style="color:#337ab7;font-weight:light;"></i></a>
    <span class=" mb-0 h3" style="text-align:left;margin-right:auto;color:#337ab7;font-size:21px;">Voucher</span>
     
  </div>
</nav>
<div class="container" >
<form  method="POST"  action="Voucher.php" >
<p id="error" style="text-align:center">

</p>

<div class="form-group row">
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Date :-</label>
<input type="date" class="form-control" name="datepurchase" id="datepurchase" value="<?php echo $d;?>" readonly>
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Supplier :-</label>
<select class="form-control" name="supplierid" id="supplierid">
<?php 
$output='<option selected disabled>Select Supplier Name</option>';
$query="select SupplierID,AgencyName from tblsupplier";
$result=mysqli_query($con,$query)->fetch_all(MYSQLI_ASSOC);
foreach($result as $row)
{
	$output.='<option value="'.$row['SupplierID'].'">'.$row['AgencyName'].'</option>';
}
echo $output;
?>
</select>
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Pending Amount :-</label>
<input type="number" class="form-control" name="pendingamt" id="pendingamt" readonly>
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Paid Amount :-</label>
<input type="number" class="form-control" name="pamt" id="pamt">
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Cash :-</label>
<input type="number" class="form-control" name="cashamt" id="cashamt">
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Online :-</label>
<input type="number" class="form-control" name="onlineamt" id="onlineamt">
</div>
<div class="col-sm-6 mb-3 sm-mb-0">
<label class="" style="font-weight:bold;">Narration :-</label>
<textarea class="form-control" name="narration" id="narration"></textarea>
</div>
</div>

<div style="text-align:center" style="">
    <input type="submit" class="btn btn-outline-primary form-control" name="Save" id="insert_form" style="width:100px;" value="Save" style="padding-right:30px;">
</div>

</form>
</div>

</body>
</html>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){

$('#supplierid').on('change', function(event){
		  let supid=$(this).val(); 
		  let flag=1;
	$.ajax({
		url: "fetchValue.php",
		type: "POST",
		data: {supid: supid,flag:flag},
		success:function(data)
            {
			var html=data;
                $('#pendingamt').val(html); 
            }
		})
});



$('#insert_form').on('submit', function(event){
        event.preventDefault();
        var error = '';
        var form_data = $(this).serialize();
	
        if(error == '')
        {
          $.ajax({
            url:"Voucher.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
            $('#error').html('<div class="alert alert-success alert-dismissible"> <button type="button" class="close" data-dismiss="alert">&times;</button> <strong>Record Save Successfully</strong> </div>');
            }
          });   
        }
        else
        {
          $('#error').html('<div class="alert alert-danger">'+error+'</div>');
        }
}); 




});
</script>





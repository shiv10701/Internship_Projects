<?php
session_start();

$name=$_COOKIE['loginname'];

if($name=="")
{
header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Medical</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
   <link href="line-awesome/css/line-awesome.min.css" rel="stylesheet">
</head>
<body>

<div class="header" style="background-color:white">
<div class="header-left" style="top:15">
<a  class="logo" style="margin-left:0px;top:15">
<!--<img src="img/yashlogo1.png" width="115" height="65" alt=""> -->
<span class="" style="text-align:left;color:#337ab7;margin-bottom:10px;"><?php echo ""; ?></span>
</a>
</div>

<a href="index.php"  class="mobile_btn float-left" style="color:#337ab7" ><i class="las la-arrow-left" ></i></a>
<a id="mobile_btn" class="mobile_btn float-left" style="color:#337ab7" href="index.php"><i class="las la-arrow-left"></i></a>

<div class="dropdown mobile-user-menu float-right" >
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" style="color:#337ab7;padding-right:15px;"><i class="las la-ellipsis-v"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
           
						 
                    <a class="dropdown-item" href="logout.php">Logout</a>
				
                </div>
</div>
</div>
     
<div class="card-columns" style="padding-top:60px;">
<a href="Sale.php"  style="text-decoration:none;color:white;">
        <div class="card bg-warning" style="width:47%;margin-left:10px;float:left;background-color:orange">
             <img class="card-img-top" src="image/Bill.png" alt="Card image" style="width:100%;">
    <div class="card-body text-center">
      <p class="card-text" style="font-weight:bold;font-size:18px;font-family:cambria;color:white;">Sale</p>
    </div>
  </div>
</a>
  <a href="Voucher.php" style="text-decoration:none;color:white;">
        <div class="card" style="width:47%;margin-left:10px;float:left;background-color:#da7f37 !important;">
             <img class="card-img-top" src="img/new_requirement.png" alt="Card image" style="width:100%;">
    <div class="card-body text-center">
      <p class="card-text" style="font-weight:bold;font-size:18px;font-family:cambria;">Voucher</p>
    </div>
  </div>
  </a>
  
    <?php if($name=="Admin"){?>
 <a href="Purchase.php" style="text-decoration:none;color:white;">
        <div class="card " style="width:47%;margin-left:10px;float:left;background-color: #92e242 !important;">
             <img class="card-img-top" src="image/PO1.png" alt="Card image" style="width:100%;">
    <div class="card-body text-center">
      <p class="card-text" style="font-weight:bold;font-size:18px;font-family:cambria;">Purchase</p>
    </div>
  </div>
  </a>

  
   <a href="Expenses.php" style="text-decoration:none;color:white;">
        <div class="card bg-success" style="width:47%;margin-left:10px;float:left;background-color:leafgreen;">
             <img class="card-img-top" src="img/customer.png" alt="Card image" style="width:100%;">
    <div class="card-body text-center">
      <p class="card-text" style="font-weight:bold;font-size:18px;font-family:cambria;">Expenses</p>
    </div>
  </div>
  </a>
  
     
      <a href="SupplierRegistration.php" style="text-decoration:none;color:white;">
        <div class="card bg-warning" style="width:47%;margin-left:10px;float:left;background-color:magenta;">
             <img class="card-img-top" src="img/client_report.png" alt="Card image" style="width:100%;">
    <div class="card-body text-center">
      <p class="card-text" style="font-weight:bold;font-size:18px;font-family:cambria;">Supplier Registration</p>
    </div>
  </div>
  </a>
  <a href="Todays.php" style="text-decoration:none;color:white;">
        <div class="card bg-success" style="width:47%;margin-left:10px;float:left;background-color:purple;">
             <img class="card-img-top" src="image/Payment-Due.png" alt="Card image" style="width:100%;">
    <div class="card-body text-center">
      <p class="card-text" style="font-weight:bold;font-size:18px;font-family:cambria;">Todays Report</p>
    </div>
  </div>
  </a>
  
  <a href="Receipt.php" style="text-decoration:none;color:white;">
        <div class="card bg-primary" style="width:47%;margin-left:10px;float:left;background-color:orange;">
             <img class="card-img-top" src="image/Receipt.png" alt="Card image" style="width:100%;">
    <div class="card-body text-center">
      <p class="card-text" style="font-weight:bold;font-size:18px;font-family:cambria;">Receipt</p>
    </div>
  </div>
  </a>
	<?php }?>
     
  
   
<br>
<br>
<br>
<br>
</div> 


</body>
</html>
<?php
}
?>
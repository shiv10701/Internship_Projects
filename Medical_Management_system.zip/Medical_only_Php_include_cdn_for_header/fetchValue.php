<?php

if(isset($_REQUEST['flag']))
{
	if($_REQUEST['flag']==1)
	{
		$supplierid=$_POST['supid'];
$connect = new PDO("mysql:host=localhost;dbname=medical","root", "");
$output='';
$query="select Balance from tblsupplier where SupplierID='$supplierid'";
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();
foreach($result as $row)
{
    $output=$row['Balance'];
}

echo $output;

}



if($_REQUEST['flag']==2)
	{
		$customerid=$_POST['cusid'];
$connect = new PDO("mysql:host=localhost;dbname=medical","root", "");
$output='';
$query="select MobileNo from tblcustomer where CustomerID='$customerid'";
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();
foreach($result as $row)
{
    $output=$row['MobileNo'];
}

echo $output;

}




if($_REQUEST['flag']==3)
	{
		$customerid=$_POST['cusid'];
$connect = new PDO("mysql:host=localhost;dbname=medical","root", "");
$output='';
$query="select Balance from tblcustomer where CustomerID='$customerid'";
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();
foreach($result as $row)
{
    $output=$row['Balance'];
}

echo $output;

}
}

?>
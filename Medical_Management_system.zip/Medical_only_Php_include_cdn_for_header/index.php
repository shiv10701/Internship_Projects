<?php
session_start();
error_reporting(0);
include('dbconection.php');

if(isset($_POST['btnLogin']))
{
	$uname=$_POST['txtMobileNo'];
	$pwd=$_POST['txtPassword'];
	
//$query="select 	EmployeeID,EmployeeUserName,EmployeePassword from tblemployeeregistration where EmployeeUserName='$uname' and EmployeePassword='$pwd'";

$query=mysqli_query($con,"select Name from tbllogin where UserName='$uname' and Password='$pwd'");

$ret=mysqli_fetch_array($query);
 if($ret>0)
	{
	
	setcookie("loginname",$ret['Name']);	
	
     echo "<script>alert('Login Successfully....');</script>";
     echo "<script>location='dashboard.php'</script>";
    }
    else
	{
       echo "<script>alert('Invalid  Username And Password....');</script>";
    }
	
}
if(isset($_POST['btnCancel']))
{
	
}

if(strlen($_SESSION['loginname']==0))
{


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
   <script src='jquery-3.2.1.min.js' type='text/javascript'></script>
   <script src='select2/dist/js/select2.min.js' type='text/javascript'></script>
   <link href='select2/dist/css/select2.min.css' rel='stylesheet' type='text/css'>
   <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <style>
           body {
        background-color: #F3EBF6;
        font-family: 'Cambria', sans-serif;
    }
    
    .main {
        background-color: #FFFFFF;
        width: 100%;
        height: auto;
        margin: 7em auto;
        border-radius: 1.5em;
        box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
    }
    
    .sign {
        padding-top: 40px;
        color: #8C55AA;
        font-family: 'Cambria', sans-serif;
        font-weight: bold;
        font-size: 23px;
    }
    
    .un {
    width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Cambria', sans-serif;
    }
    
    form.form1 {
        padding-top: 40px;
    }
    
    .pass {
            width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Cambria', sans-serif;
    }
    
   
    .un:focus, .pass:focus {
        border: 2px solid rgba(0, 0, 0, 0.18) !important;
        
    }
    
    .sub {
      cursor: pointer;
        border-radius: 5em;
        color: #fff;
       /* background: linear-gradient(to right, #9C27B0, #E040FB);*/
       background: linear-gradient(to right,#f37f45,#ed2e93b0);
        border: 0;
        padding-left: 40px;
        padding-right: 40px;
        padding-bottom: 10px;
        padding-top: 10px;
        font-family: 'Cambria', sans-serif;
        margin-left: 35%;
        font-size: 18px;
        box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.04);
           text-shadow: 0px 0px 3px rgba(117, 117, 117, 0.12);
    }
    
    .forgot {
        text-shadow: 0px 0px 3px rgba(117, 117, 117, 0.12);
        color: #E1BEE7;
        padding-top: 15px;
    }
    
    a {
        text-shadow: 0px 0px 3px rgba(117, 117, 117, 0.12);
        color: #E1BEE7;
        text-decoration: none
    }
    
  </style>

</head>
<body>

<nav class="navbar" style="background-color:#FBFBFB;box-shadow: 0 4px 2px -2px gray;height:55px;">
  <div class="container-fluid" style="padding:0px;">
     <a href="#" class="navbar-brand mb-0 h3" ><i class="fa fa-arrow-left" style="color:#337ab7;font-weight:light;"></i></a>
    <span class=" mb-0 h3" style="text-align:left;margin-right:auto;color:#337ab7;font-size:21px;">Login</span>
     
  </div>
</nav>


<div class="container" >

      
     <div class="main">
         
           <img src="" class="sign" width="100%" style="padding-left:15px;padding-right:15px;">
    <!--<p class="sign" align="center">Sign in</p>-->
    <form class="form1" method="post" action="index.php" enctype="multipart/form-data">
      <input class="un " type="text" align="center" placeholder="Enter Mobile No" name="txtMobileNo">
      <input class="pass" type="password" align="center" placeholder="Enter Password" name="txtPassword">
      <button type="submit" class="sub" align="center" name="btnLogin" style="color:white;font-weight: bold;">LOGIN</button><br><br>
    <!--  <p class="forgot" align="center"><a href="#">Forgot Password?</p>-->
      </form>          
    </div>
    

</body>
</html>
<?php
}
else
{
    header('location:dashboard.php');
}?>
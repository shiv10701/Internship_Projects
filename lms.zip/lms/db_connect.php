<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "lms_db";
  $conn = new mysqli($servername,$username,$password,$dbname);
  
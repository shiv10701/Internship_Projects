<?php
include 'db_connect.php';
if(isset($_GET['id'])){
	$id;
	$Name;
	$Date_Of_Receipt;
	$Date_Published;
	$Pages;
	$Price;
	$Type;
	$Publisher;
$magazine = $conn->query("SELECT * FROM magazines where id=".$_GET['id'])->fetch_assoc();
$id=$magazine['id'];
$Name=$magazine['Name'];
$Date_Of_Receipt=$magazine['Date_Of_Receipt'];
$Date_Published=$magazine['Date_Published'];
$Pages=$magazine['Pages'];
$Price=$magazine['Price'];
$mType=$magazine['mType'];
$Publisher=$magazine['Publisher'];
}
?>
<div class="container-fluid">
    <form action="" id="manage_magazine">
		<div class=" mt-3">
            <label for="title">Type</label>
            <input type="text" id="mType" name="mType" class="form-control" <?php if(!empty($mType)){echo "value=\"".$mType."\"";}else{}?> required>
        </div>
        <div class=" mt-3">
            <label for="title">Name</label>
        <input type="hidden" name="id" <?php if(!empty($id)){echo "value=\"".$id."\"";}else{}?>>
            <input type="text" id="Name" name="Name" class="form-control" <?php if(!empty($Name)){echo "value=\"".$Name."\"";}else{}?> required>
        </div>
		<div class=" mt-3">
            <label for="title">Date Of Receipt</label>
            <input type="date" id="DOR" name="DOR" class="form-control" <?php if(!empty($Date_Of_Receipt)){echo "value=\"".$Date_Of_Receipt."\"";}else{}?> required>
        </div>
		<div class=" mt-3">
            <label for="title">Date Published</label>
            <input type="date" id="DP" name="DP" class="form-control" <?php if(!empty($Date_Published)){echo "value=\"".$Date_Published."\"";}else{}?> required>
        </div>
		<div class=" mt-3">
            <label for="title">Pages</label>
            <input type="number" id="Pages" name="Pages" class="form-control" <?php if(!empty($Pages)){echo "value=\"".$Pages."\"";}else{}?> required>
        </div>
		<div class=" mt-3">
            <label for="title">Price</label>
            <input type="number" id="Price" name="Price" class="form-control" <?php if(!empty($Price)){echo "value=\"".$Price."\"";}else{}?> required>
        </div>
		<div class=" mt-3">
            <label for="title">Publisher</label>
            <input type="text" id="Publisher" name="Publisher" class="form-control" <?php if(!empty($Publisher)){echo "value=\"".$Publisher."\"";}else{}?> required>
        </div>
    </form>
</div>
<script>
$('#title').trigger('click')
  $('input, textarea').each(function(){
        $(this).trigger('focus')
        $(this).trigger('blur')
    })
function displayIMG(input) {
    $('#img-field').removeAttr('src')
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#img-fname').html(input.files[0]['name'])
                $('#img-field').attr('src', e.target.result).width(100).height(150);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
$('#manage_magazine').submit(function(e){
    e.preventDefault()
    start_load();
    $.ajax({
        url:'ajax.php?action=save_magazine',
        method:'POST',
        data:new FormData($(this)[0]),
        enctype: 'multipart/form-data',
        contentType: false, 
        processData: false,
        error:err=>{
            console.log(err)
            alert("An error occured")
        },
        success:function(resp){
            if(resp == 1){
                alert('Data successfully saved.')
                location.reload()
            }
        }
    })
})
</script>
<style>
#img-field{
    max-height:150px;
    max-width:100px;
}
</style>
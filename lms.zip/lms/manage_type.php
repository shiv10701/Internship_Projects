<?php
include 'db_connect.php';
if(isset($_GET['id'])){
	$typename;
$type = $conn->query("SELECT * FROM type where TypeID=".$_GET['id'])->fetch_assoc();
$id=$type['TypeID'];
$typename=$type['TypeName'];
}
?>
<div class="container-fluid">
    <form action="" id="manage_type">
        <div class=" mt-3">
            <label for="title"  >Book Type</label>
        <input type="hidden" name="id" <?php if(!empty($id)){echo "value=\"".$id."\"";}else{}?>>
            <input type="text" id="TypeName" name="TypeName" class="form-control" <?php if(!empty($typename)){echo "value=\"".$typename."\"";}else{}?> required>
        </div>
    </form>
</div>
<script>
$('#title').trigger('click')
  $('input, textarea').each(function(){
        $(this).trigger('focus')
        $(this).trigger('blur')
    })
function displayIMG(input) {
    $('#img-field').removeAttr('src')
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#img-fname').html(input.files[0]['name'])
                $('#img-field').attr('src', e.target.result).width(100).height(150);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
$('#manage_type').submit(function(e){
    e.preventDefault()
    start_load();
    $.ajax({
        url:'ajax.php?action=save_type',
        method:'POST',
        data:new FormData($(this)[0]),
        enctype: 'multipart/form-data',
        contentType: false, 
        processData: false,
        error:err=>{
            console.log(err)
            alert("An error occured")
        },
        success:function(resp){
            if(resp == 1){
                alert('Data successfully saved.')
                location.reload()
            }
        }
    })
})
</script>
<style>
#img-field{
    max-height:150px;
    max-width:100px;
}
</style>
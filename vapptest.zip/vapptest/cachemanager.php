<?php
require_once 'dbconnection.php';

$cache_file="cache/index.cache.php";
if(file_exists($cache_file)){
	include($cache_file);
}else{
$query="select vappid,voterimage,vname,englishname,grampanchayat,wardname,isgoodbad from vappjeur where vname!=''";
      $result=mysqli_query($con,$query);
	  $str='';
      	foreach($result as $row)
      {
        $vid=$row['vappid'];
        $img=$row['voterimage'];
        $vname=$row['vname'];
        $englishname=$row['englishname'];
        $vlg=$row['grampanchayat'];
        $ward=$row['wardname'];
        $isgoodbad=$row['isgoodbad']==1?"bg-success":($row['isgoodbad']==2?"bg-danger":($row['isgoodbad']==3?"bg-warning":""));
      $str.=<<<bar
<tr onclick="window.location.assign('voterinfo?viid=$vid')">
        <td style="padding-right:0px;"><img src="https://transconabiz.ca/wp2019/wp-content/uploads/2022/01/blank-welcome.png"  style="height:50px;width:50px;"></td>
        <td><span style="margin-top:auto;margin-bottom:auto;">$vname</span><span hidden>$englishname</span></td>
        <td><div class="row" style="padding:0px;"><div class="col-12 d-flex justify-content-center" style="width:100%;"><span style="color:white">joe@gmail.com</span></div><div class="col-12 d-flex justify-content-end" style="padding:0px;"><span class="text-danger" style="font-size:13px;">Village -$vlg</span><span class="text-danger" style="font-size:13px;"> Ward No:$ward</span></div></div></td>
        <td class="$isgoodbad" ></td>
      </tr>
      
bar;
      }
	
	$handle=fopen($cache_file,'w');
	fwrite($handle,$str);
	fclose($handle);
	echo $str;
}
?>
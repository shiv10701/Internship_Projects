<?php
$con=mysqli_connect("localhost","root","");
$ok=mysqli_select_db($con,"voterapp");
?>
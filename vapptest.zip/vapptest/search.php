<?php
require_once 'dbconnection.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Matdar Yadi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

    

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Crimson+Pro&family=Yellowtail">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
        
        <link href="https://nightly.datatables.net/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />
    <script src="https://nightly.datatables.net/js/jquery.dataTables.js"></script>
        <style>
        
        .form-control:focus {
        border-color: #28a745;
        box-shadow: 0 0 0 0.01rem rgba(40, 167, 69, 0.25);
    }
        
            img[alt="www.000webhost.com"]{display:none;}
            

        </style>
  </head>
<body style="">
<!-- sidebar-->
<div class="offcanvas offcanvas-start " id="demo" style="width:65%;">
  <div class="offcanvas-header" style="background-color:#f54284;height:30%;">    
<div class="row"><div class="col-12"><span class="material-symbols-rounded" data-bs-dismiss="offcanvas" style="float:right;font-size:30px;margin-bottom:-15px;cursor: pointer;color:white;">close</span></div><div class="col-12 d-flex justify-content-center"><img src="https://upload.wikimedia.org/wikipedia/commons/d/d3/User_Circle.png"
style="height:100px;width:100px;"></div>
    <div class="col-12 d-flex justify-content-center" style="margin-top:15px;color:white;"><span style="font-size:18px;">Shivam Khandelwal</span></div>
</div>
  </div>
  <div class="" style="">
  
    <div id="accordion">
    <div class="card " >
      <div class="card-header " style="background-color:white;">
        <a class="" data-bs-toggle="collapse" href="#collapseOne" style="text-decoration:none;color:black;">
            <div class="" style="font-size:20px;magin-left:10px;"><div class="row " style=""><div class="col-2" style="width:20%;margin-top:auto;margin-bottom:auto;"><span class="material-symbols-rounded">
widgets
</span></div><div class="col-5" style="width:50%;margin-top:auto;margin-bottom:auto;">Dashboard</div><div class="col-2 dropdown-toggle"></div></div></div>
        </a>
      </div>
      <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
<div class=" list-group" style="width:100%;height:100%;">
    <a href="index.php?usrname=<?php echo $usrname;?>" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">home</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Home</div></div></a>
    <a href="profile.php?usrname=<?php echo $usrname;?>" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="background-color:orange;width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">account_circle</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Profile</div></div></a>
  </div>
      </div>
    </div>
    
    <div class="card " >
      <div class="card-header " style="background-color:white;">
        <a class="" data-bs-toggle="collapse" href="#collapseTwo" style="text-decoration:none;color:black;">
            <div class="" style="font-size:20px;magin-left:10px;"><div class="row " style=""><div class="col-2" style="width:20%;margin-top:auto;margin-bottom:auto;"><span class="material-symbols-rounded">
stadium
</span></div><div class="col-5" style="width:50%;margin-top:auto;margin-bottom:auto;">Events</div><div class="col-2 dropdown-toggle"></div></div></div>
        </a>
      </div>
      <div id="collapseTwo" class="collapse " data-bs-parent="#accordion">
<div class=" list-group" style="width:100%;height:100%;">
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">stars</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Marathon</div></div></a>
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">star_half</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Half-Marathon</div></div></a>
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">10k</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">10 Km</div></div></a>
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">5k</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">5 Km</div></div></a>
  </div>
      </div>
    </div>
    
    
  </div>
  
  
  
  
  
  
    </div>
    
  
</div>
<!-- disebar closed-->


<!-- navbar -->
<div class="container-fluid d-flex">
<nav class="navbar navbar-expand-sm  fixed-top " style="background-color:#f54284;height:90px;">
<div class="row" style="height:100%;width:100%;margin:0px;padding:0px;">

<div class="col-sm-1  d-md-none" style="margin-top:auto;margin-bottom:auto;padding-left:max(30px,2.3vw);width:12%;">
<a href="index" style="text-decoration:none;color:white;"><span class="material-symbols-rounded" style="color:white;font-size:max(24px,2.6vw);padding-top:10px;" type="button" >arrow_back_ios_new</span>
</a></div>




<div class="col-sm-3 col-md-4 d-flex justify-content-center" style="margin-top:auto;margin-bottom:auto;width:80%;padding-left:min(150px,5vw);">
<a href="index.php?usrname=<?php echo $usrname;?>"  style="text-decoration:none;" >
<span class="" style="font-size:max(22px,2.5vw);color:white;margin-top:auto;margin-bottom:auto;font-weight:bold;">Ahmednagar </span>
</a>
</div>



<div class="col-md-2 d-none d-md-block;" style="width:10%;"></div>

</div>
</nav>
</div>
<!--------------nav closed ------------------------>





<div class="container-fluid " style="position:sticky;background-color:white;top:90px;padding-top:10px;padding-bottom:10px;z-index:1">

<div class="input-group " style="width:100%;">
    <input type="text" class="form-control border-bottom border-3" id="searchtextval" placeholder="शोधा" style="width:80%;border:none;border-radius:0px;font-size:18px;">
    <span class="input-group-text border-bottom border-3" style="width:20%;background-color:white;border:none;border-radius:0px;">
    <span class="material-symbols-rounded" style="font-size:30px;">
search
</span>
    </span>
  </div> 
</div>

<div class="container-fluid overflow-auto" style="height100%;margin-top:120px;margin-bottom:20px;padding:0px;">
<div class="container-fluid d-flex justify-content-center" style="height:5000px;overflow:hidden;" id="spinnerloadingpage">
  <div class="spinner-border text-info" style="height:75px;width:75px;margin-top:100px;"></div>
</div>

<table class="table" id="searchtable" data-page-length="100">
    <thead>
    <tr>
  <th style="width: 8%"></th>
  <th style="width: 70%"></th>
  <th style="width: 50%"></th>
  <th style="width:  2%;padding:0px;margin:0px;"></th>
</tr>
    </thead>
    <tbody>
      <?php
      $query="select vappid,voterimage,vname,englishname,grampanchayat,wardname,isgoodbad from vappjeur where vname!=''";
      $result=mysqli_query($con,$query);
      /*foreach($result as $row)
      {
      ?>
      <tr onclick="window.location.assign('voterinfo?viid=<?php echo $row['vappid'];?>')">
        <td style="padding-right:0px;"><img src="<?php echo $row['voterimage']!=""?"data:image/jpeg;base64,".base64_encode($row['voterimage'] ):"https://transconabiz.ca/wp2019/wp-content/uploads/2022/01/blank-welcome.png";?>"  style="height:50px;width:50px;"></td>
        <td><span style="margin-top:auto;margin-bottom:auto;"><?php echo $row['vname'];?></span><span hidden><?php echo $row['englishname'];?></span></td>
        <td><div class="row" style="padding:0px;"><div class="col-12 d-flex justify-content-center" style="width:100%;"><span style="color:white">joe@gmail.com</span></div><div class="col-12 d-flex justify-content-end" style="padding:0px;"><span class="text-danger" style="font-size:13px;">Village -<?php echo $row['grampanchayat']?></span><span class="text-danger" style="font-size:13px;"> Ward No:<?php echo $row['wardname'];?></span></div></div></td>
        <td class="<?php echo $row['isgoodbad']==1?"bg-success":($row['isgoodbad']==2?"bg-danger":($row['isgoodbad']==3?"bg-warning":""));?>" ></td>
      </tr>
      <?php } ?>
      <?php 
      $str='';
      	foreach($result as $row)
      {
        $vid=$row['vappid'];
        $img=$row['voterimage'];
        $vname=$row['vname'];
        $englishname=$row['englishname'];
        $vlg=$row['grampanchayat'];
        $ward=$row['wardname'];
        $isgoodbad=$row['isgoodbad']==1?"bg-success":($row['isgoodbad']==2?"bg-danger":($row['isgoodbad']==3?"bg-warning":""));
      $str.=<<<bar
<tr onclick="window.location.assign('voterinfo?viid=$vid')">
        <td style="padding-right:0px;"><img src="https://transconabiz.ca/wp2019/wp-content/uploads/2022/01/blank-welcome.png"  style="height:50px;width:50px;"></td>
        <td><span style="margin-top:auto;margin-bottom:auto;">$vname</span><span hidden>$englishname</span></td>
        <td><div class="row" style="padding:0px;"><div class="col-12 d-flex justify-content-center" style="width:100%;"><span style="color:white">joe@gmail.com</span></div><div class="col-12 d-flex justify-content-end" style="padding:0px;"><span class="text-danger" style="font-size:13px;">Village -$vlg</span><span class="text-danger" style="font-size:13px;"> Ward No:$ward</span></div></div></td>
        <td class="$isgoodbad" ></td>
      </tr>
      
bar;
      }
      echo $str;*/
      //require_once 'cachemanager.php';
      echo file_get_contents("cache/index.cache.php");
      ?>
      
     
    </tbody>
  </table>

</div>

<script>
    $(document).ready( function () {
  var table = $('#searchtable').DataTable({
    "dom": '<"top"i>rt<"bottom"><"clear">'
  });
  $("#spinnerloadingpage").remove();
  $('#searchtextval').on( 'keyup click', function () {
    table.search($('#searchtextval').val()).draw();
  } );
} );
  </script>
</body>
</html>



  

<?php 
require_once 'dbconnection.php';

if(isset($_GET['viid']))
{
    $vidget=$_GET['viid'];
    $query="select * from vappjeur where vappid='$vidget'";
    $result=mysqli_query($con,$query);
    foreach($result as $row)
    {
        $wardnamevoter=$row['wardname'];
        $grampanchayatvoter=$row['grampanchayat'];
        $slnovoter=$row['slno'];
        $housenovoter=$row['houseno'];
        $vnamevoter=$row['vname'];
        $relnamevoter=$row['relname'];
        $relationvoter=$row['relation'];
        $cardnovoter=$row['cardno'];
        $sexvoter=$row['sex'];
        $agevoter=$row['age'];
        $refnovoter=$row['refno'];
        $contact1voter=$row['contactno1'];
        $contact2voter=$row['contactno2'];
        $englishnamevoter=$row['englishname'];
        $isvotedvoter=$row['isvoted'];
        $isgoodbadvoter=$row['isgoodbad'];
        $voterimagevoter=$row['voterimage'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Matdar Yadi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Crimson+Pro&family=Yellowtail">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

        <style>
        
        .form-control:focus {
        border-color: #28a745;
        box-shadow: 0 0 0 0.01rem rgba(40, 167, 69, 0.25);
    }
        img[alt="www.000webhost.com"]{display:none;}
        </style>
  </head>
<body style="">
<!-- sidebar-->
<div class="offcanvas offcanvas-start " id="demo" style="width:65%;">
  <div class="offcanvas-header" style="background-color:#f54284;height:30%;">    
<div class="row"><div class="col-12"><span class="material-symbols-rounded" data-bs-dismiss="offcanvas" style="float:right;font-size:30px;margin-bottom:-15px;cursor: pointer;color:white;">close</span></div><div class="col-12 d-flex justify-content-center"><img src="https://upload.wikimedia.org/wikipedia/commons/d/d3/User_Circle.png"
style="height:100px;width:100px;"></div>
    <div class="col-12 d-flex justify-content-center" style="margin-top:15px;color:white;"><span style="font-size:18px;">Shivam Khandelwal</span></div>
</div>
  </div>
  <div class="" style="">
  
    <div id="accordion">
    <div class="card " >
      <div class="card-header " style="background-color:white;">
        <a class="" data-bs-toggle="collapse" href="#collapseOne" style="text-decoration:none;color:black;">
            <div class="" style="font-size:20px;magin-left:10px;"><div class="row " style=""><div class="col-2" style="width:20%;margin-top:auto;margin-bottom:auto;"><span class="material-symbols-rounded">
widgets
</span></div><div class="col-5" style="width:50%;margin-top:auto;margin-bottom:auto;">Dashboard</div><div class="col-2 dropdown-toggle"></div></div></div>
        </a>
      </div>
      <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
<div class=" list-group" style="width:100%;height:100%;">
    <a href="index.php?usrname=<?php echo $usrname;?>" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">home</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Home</div></div></a>
    <a href="profile.php?usrname=<?php echo $usrname;?>" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="background-color:orange;width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">account_circle</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Profile</div></div></a>
  </div>
      </div>
    </div>
    
    <div class="card " >
      <div class="card-header " style="background-color:white;">
        <a class="" data-bs-toggle="collapse" href="#collapseTwo" style="text-decoration:none;color:black;">
            <div class="" style="font-size:20px;magin-left:10px;"><div class="row " style=""><div class="col-2" style="width:20%;margin-top:auto;margin-bottom:auto;"><span class="material-symbols-rounded">
stadium
</span></div><div class="col-5" style="width:50%;margin-top:auto;margin-bottom:auto;">Events</div><div class="col-2 dropdown-toggle"></div></div></div>
        </a>
      </div>
      <div id="collapseTwo" class="collapse " data-bs-parent="#accordion">
<div class=" list-group" style="width:100%;height:100%;">
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">stars</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Marathon</div></div></a>
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">star_half</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">Half-Marathon</div></div></a>
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">10k</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">10 Km</div></div></a>
    <a href="#" class="list-group-item list-group-item-action " ><div class="row" style=""><div class="col-1 d-flex justify-content-start" style="width:20%;margin-left:-10px;"><span class="d-flex justify-content-start" style="width:5px;"></span></div><div class="col-2" style="margin-top:auto;margin-bottom:auto;padding-left:35px;width:25%;"><span class="material-symbols-rounded " style="margin-top:auto;margin-bottom:auto;">5k</span></div><div class="col-8" style="margin-top:auto;margin-bottom:auto;width:50%;">5 Km</div></div></a>
  </div>
      </div>
    </div>
    
    
  </div>
  
  
  
  
  
  
    </div>
    
  
</div>
<!-- disebar closed-->


<!-- navbar -->
<div class="container-fluid d-flex">
<nav class="navbar navbar-expand-sm  fixed-top " style="background-color:#f54284;height:90px;">
<div class="row" style="height:100%;width:100%;margin:0px;padding:0px;">

<div class="col-sm-1  d-md-none" style="margin-top:auto;margin-bottom:auto;padding-left:max(30px,2.3vw);width:12%;">
<a href="search"  style="text-decoration:none;" ><span class="material-symbols-rounded" style="color:white;font-size:max(24px,2.6vw);padding-top:10px;" type="button" >arrow_back_ios_new</span></a>
</div>




<div class="col-sm-3 col-md-4 d-flex justify-content-center" style="margin-top:auto;margin-bottom:auto;width:80%;padding-left:min(150px,5vw);">
<a href="#"  style="text-decoration:none;" >
<span class="" style="font-size:max(22px,2.5vw);color:white;margin-top:auto;margin-bottom:auto;font-weight:bold;">Voter Info </span>
</a>
</div>



<div class="col-md-2 d-none d-md-block;" style="width:10%;"></div>

</div>
</nav>
</div>
<!--------------nav closed ------------------------>

<div class="container-fluid" style="padding-top:100px;position:fixed;background-color:white;">
<div class="row" style="margin-left:10px;margin-right:10px;">
<div class="col-2 " style="width:15%;margin-top:auto;margin-bottom:auto;margin-bottom:auto;">
<div class="bg-primary rounded-circle" style="height:35px;width:40px;"><span class="material-symbols-rounded d-flex justify-content-center" style="color:white;padding-top:5px;">
call
</span></div>
</div>
<div class="col-2" style="width:15%;margin-top:auto;margin-bottom:auto;">
<div class="bg-success rounded" style="height:35px;width:40px;"><span class="material-symbols-rounded d-flex justify-content-center" style="color:white;padding-top:5px;">
share
</span></div>
</div>
<div class="col-2 d-flex justify-content-center" style="width:25%;text-align:center;margin-top:auto;margin-bottom:auto;">
<select class="form-control d-flex justify-content-center" style="width:100%;" id="selectgoodbad">
<option <?php echo $isgoodbadvoter==1?"selected":"";?> class="text-bg-success" value="1" >आपले</option>
<option class="text-bg-danger" <?php echo $isgoodbadvoter==2?"selected":"";?> value="2" >विरोधी</option>
<option class="text-bg-warning" <?php echo $isgoodbadvoter==3?"selected":"";?> value="3" >संदिग्ध</option>
<option <?php echo $isgoodbadvoter==0?"selected":"";?> value="0">इतर</option>
</select>
</div>
<div class="col-2" style="width:35%;margin-top:auto;margin-bottom:auto;">
<div class="input-group border" style="width:100%;" type="button" id="btnvotedyes">
      <span class="input-group-text" style="background-color:white;border:none;width:60%;">Voted</span>
            <span class="input-group-text text-success" style="background-color:white;border:none;width:20%;"><span class="material-symbols-rounded" style="font-size:30px;">
done
</span></span>
    </div>
    
<div class="input-group border" style="width:100%;" type="button"  id="btnvotedno">
      <span class="input-group-text" style="background-color:white;border:none;width:60%;">Voted</span>
            <span class="input-group-text text-danger" style="background-color:white;border:none;width:20%;"><span class="material-symbols-rounded" style="font-size:30px;">
close
</span></span>
    </div>
    
    
    </div>
</div>
<hr style="margin-top:10px;margin-bottom:10px;color:black;">
</div>




<div class="container-fluid" style="padding-top:170px;margin-bottom:70px;">
<!-- table and user photo code-->



  <div class="row">
  <div class="col-8">
  <table class="table table-borderless table-responsive" style="">
    <thead>
      <tr>
        <th></th>
        <th class="d-flex justify-content-center" style="width:10%;"></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="text-danger">Name</td>
        <td>-</td>
        <td><?php echo $vnamevoter;?></td>
      </tr>
      <tr>
        <td class="text-danger">Part No</td>
        <td>-</td>
        <td><?php echo $wardnamevoter!=""?$wardnamevoter:"-";?></td>
      </tr>
      <tr>
        <td class="text-danger">Village</td>
        <td>-</td>
        <td><?php echo $grampanchayatvoter!=""?$grampanchayatvoter:"-";?></td>
      </tr>
      <tr>
        <td class="text-danger">Sr No.</td>
        <td>-</td>
        <td><?php echo $slnovoter;?></td>
      </tr>
      <tr>
        <td class="text-danger">Age & Sex</td>
        <td>-</td>
        <td><?php echo $agevoter!=""?$agevoter:"0";?> <?php echo $sexvoter!=""?$sexvoter:"-";?></td>
      </tr>
      <tr>
        <td class="text-danger">Voter Card No.</td>
        <td>-</td>
        <td><?php echo $cardnovoter!=""?$cardnovoter:"-";?></td>
      </tr>
      <tr>
        <td class="text-danger">Assembly</td>
        <td>-</td>
        <td><?php echo $refnovoter!=""?$refnovoter:"";?></td>
      </tr>
      <tr>
        <td class="text-danger">Address</td>
        <td>-</td>
        <td>ahmednagar maharashtra</td>
      </tr>
    </tbody>
  </table>
</div><div class="col-4 d-flex justify-content-center align-self-center">
<img class="border border-2" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZqO6coF_HjVwXSWJ_Jd7qpgBkhOGz6tO7Pw&usqp=CAU" style="height:100px;width:100px;">
</div>
</div>




<!-- table and user photo code-->


<div class="row"><div class="col-10">
 <table class="table table-borderless table-responsive" >
    <thead>
      <tr>
        <th ></th>
        <th class="d-flex justify-content-center" style="width:10%;"></th>
        <th ></th>
      </tr>
    </thead>
    <tbody>
      <tr >
        <td class="text-danger">House No.</td>
        <td>-</td>
        <td><?php echo $housenovoter!=""?$housenovoter:"";?></td>
      </tr>
      <tr >
        <td class="text-danger">Booth Address</td>
        <td>-</td>
        <td></td>
      </tr>
      <tr >
        <td class="text-danger">New Address</td>
        <td>-</td>
        <td><span class="material-symbols-rounded" type="button" data-bs-toggle="modal" data-bs-target="#myModal">add_home</span></td>
      </tr>
      <tr >
        <td class="text-danger">Dead</td>
        <td>-</td>
        <td><div class="row"><div class="col-4"><input type="radio" id="isdeadyorn" name="isdeadyorn" value="No">No</div><div class="col-4"><input type="radio" id="isdeadyorn" name="isdeadyorn" value="Yes">Yes</div></div></td>
      </tr>
      <tr >
        <td class="text-danger">Mobile No. 1</td>
        <td>-</td>
        <td><span class="material-symbols-rounded" type="button" data-bs-toggle="modal" data-bs-target="#myModalmobileno1">library_add</span></td>
      </tr>
      <tr >
        <td class="text-danger">Mobile No. 2</td>
        <td>-</td>
        <td><span class="material-symbols-rounded" type="button" data-bs-toggle="modal" data-bs-target="#myModalmobileno2">library_add</span></td>
      </tr>
    </tbody>
  </table>
</div></div>
<!-- The Modal -->
<div class="modal " id="myModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">New Address</h4>
                <input type="text" hidden name="idvappjeur" value="<?php echo $vidget;?>">

        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <textarea class="form-control" name="txtnewaddress" rows="5"></textarea>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-success" name="savebtnnewaddress" id="savebtnnewaddress">Save</button>
      </div>

    </div>
  </div>
</div>


<!-- The Modal -->
<div class="modal " id="myModalmobileno1">
        <form method="post" id="savemobileno2">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Mobile No. 1</h4>
                <input type="text" hidden name="idvappjeur" value="<?php echo $vidget;?>">
        <input type="text" hidden name="action" value="savemobileno1">

        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <input type="text" name="addmobilenno1" id="addmobileno1" placeholder="Mobile No" class="form-control">
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-success" name="savebtnnewmobile2" id="savebtnnewmobile2">Save</button>
      </div>

    </div>
  </div>
 </form>
</div>

<div class="modal " id="myModalmobileno2">
    <form method="post" id="savemobileno2">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Mobile No. 2</h4>
        <input type="text" hidden name="idvappjeur" value="<?php echo $vidget;?>">
        <input type="text" hidden name="action" value="savemobileno2">
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <input type="text" name="addmobilenno2" id="addmobileno2" placeholder="Mobile No" class="form-control">
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-success" name="savebtnnewmobile2" id="savebtnnewmobile2">Save</button>
      </div>

    </div>
  </div>
  </form>
</div>




</div>










<script>
$(document).ready(function(){
<?php echo $isvotedvoter==1?'$("#btnvotedno").hide();':'$("#btnvotedyes").hide();';?>

$("#selectgoodbad").change(function(){
    let a=this.value;
    if(a==1){
    $.ajax({
            url:"voterinfosave?action=savegoodbad&iswhat=1&viidapp=<?php echo $vidget;?>",
            method:"POST",
            success:function(data)
            {
            
            }
          });} 
          if(a==2){
    $.ajax({
            url:"voterinfosave?action=savegoodbad&iswhat=2&viidapp=<?php echo $vidget;?>",
            method:"POST",
            success:function(data)
            {
            
            }
          });} 
          if(a==3){
    $.ajax({
            url:"voterinfosave?action=savegoodbad&iswhat=3&viidapp=<?php echo $vidget;?>",
            method:"POST",
            success:function(data)
            {
            
            }
          });}  
          if(a==0){
    $.ajax({
            url:"voterinfosave?action=savegoodbad&iswhat=0&viidapp=<?php echo $vidget;?>",
            method:"POST",
            success:function(data)
            {
            
            }
          });}  
          
  });

  $("#btnvotedno").click(function(){
    $(this).hide();
    $("#btnvotedyes").show();
    $.ajax({
            url:"voterinfosave?action=savevotedornot&iswhat=1&viidapp=<?php echo $vidget;?>",
            method:"POST",
            success:function(data)
            {
            
            }
          });
          
      
  });
  
  
  $("#btnvotedyes").click(function(){
    $(this).hide();
    $("#btnvotedno").show();
    $.ajax({
            url:"voterinfosave?action=savevotedornot&iswhat=0&viidapp=<?php echo $vidget;?>",
            method:"POST",
            success:function(data)
            {
            
            }
          });  
      
  });



  $('#savemobileno2').on('submit', function(event){
        event.preventDefault();
        var error = '';
        var form_data = $(this).serialize();
        
        if(error == '')
        {
          $.ajax({
            url:"voterinfosave.php",
            method:"POST",
            data:new FormData(this),
            contentType:false,
            processData:false,
            success:function(data)
            {
            alert('success');
            }
          });
            
        }
        else
        {
          alert('fail');
        }
});


$('#savemobileno1').on('submit', function(event){
        event.preventDefault();
        var error = '';
        var form_data = $(this).serialize();
        
        if(error == '')
        {
          $.ajax({
            url:"voterinfosave.php",
            method:"POST",
            data:new FormData(this),
            contentType:false,
            processData:false,
            success:function(data)
            {
            alert('success');
            }
          });
            
        }
        else
        {
          alert('fail');
        }
});
  
});
</script>

</body>
</html>



  

<?php
require_once 'dbconnection.php';
if($_POST['action']=="savemobileno2")
{
    $vid=$_POST['idvappjeur'];
    $mbno2=$_POST['addmobilenno2'];
    $query="update vappjeur set contactno2='$mbno2' where vappid='$vid'";
    mysqli_query($con,$query);
    $a=mysqli_affected_rows($con);
    
}
if($_POST['action']=="savemobileno1")
{
    $vid=$_POST['idvappjeur'];
    $mbno1=$_POST['addmobilenno1'];
    $query="update vappjeur set contactno1='$mbno1' where vappid='$vid'";
    mysqli_query($con,$query);
    $a=mysqli_affected_rows($con);
    
}
if($_REQUEST['action']=="savevotedornot")
{
    $vid=$_REQUEST['viidapp'];
    $isvotedornot=$_REQUEST['iswhat'];
    $query="update vappjeur set isvoted='$isvotedornot' where vappid=$vid";
    mysqli_query($con,$query);
}
if($_REQUEST['action']=="savegoodbad")
{
    $vid=$_REQUEST['viidapp'];
    $isgoodbad=$_REQUEST['iswhat'];
    $query="update vappjeur set isgoodbad='$isgoodbad' where vappid=$vid";
    mysqli_query($con,$query);
}
?>